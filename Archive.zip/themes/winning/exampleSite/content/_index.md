---
title: CV
---
# Your name here
Bacon ipsum dolor amet bacon filet mignon bresaola, pork burgdoggen shankle doner. Tenderloin short loin bresaola landjaeger porchetta. Swine venison salami brisket ground round biltong chuck short ribs ribeye shoulder leberkas sausage shankle. Pork chop ground round ball tip picanha. Pig salami biltong buffalo sausage rump ball tip. Pork loin shoulder biltong, meatloaf leberkas cupim chuck.

{{% grid %}}

{{% column -span-cols-6 -m-right-2 %}}
## Professional Experience
###### *May 2015 - Present*
### Company A — UI/UX Lead 

Bacon ipsum dolor amet bacon filet mignon bresaola, pork burgdoggen shankle doner. Tenderloin short loin bresaola landjaeger porchetta. Swine venison salami brisket ground round biltong chuck short ribs ribeye shoulder leberkas sausage shankle. Pork chop ground round ball tip picanha. Pig salami biltong buffalo sausage rump ball tip. Pork loin shoulder biltong, meatloaf leberkas cupim chuck.

* Leberkas sausage shankle. Pork chop ground round ball tip picanha.
* Gamet bacon filet mignon bresaola, pork burgdoggen shankle doner. Tenderloin
* Pig salami biltong buffalo sausage rump ball tip. Pork loin shoulder biltong


###### *September 2010 - April 2015*
### Company B — Managing Director/Owner

Swine venison salami brisket ground round biltong chuck short ribs ribeye

* Leberkas sausage shankle. Pork chop ground round ball tip picanha.
* Pig salami biltong buffalo sausage rump ball tip. Pork loin shoulder biltong


{{% /column %}}

{{% column -span-cols-4 -p-left-3 %}}
#### Fluent with
  * Sketch
  * HTML5
  * CSS3, grid and flexbox
  * SVG animation & GSAP
  * PostCSS & Sass

#### Familiar with
  * Node.js
  * Riot.Js
  * Hugo.io (Static site generator)

#### Interested in
  * Web components
  * Svelte + Sapper
  * WebVR / A-Frame


#### Other Info
{{% dd %}}
- **Language:**
  1. I can speak English
- **Napoleon:**
  1. I have numchuck skills too
{{% /dd %}}


## Hobbies/Interests
I have interests...

{{% printonly %}}
##   References
Please contact me at [youremail@email.com](mailto:youremail@email.com) for references.
{{% /printonly %}}

{{% /column %}}
{{% /grid %}}
